import tkinter
import datetime

class JanelaPrincipal(tkinter.Tk):
    def __init__(self, chave=None):
        tkinter.Tk.__init__(self, chave)
        self.title("Aplicativo IMC")
        self.geometry("400x300")
        self.columnconfigure(0, minsize=250, weight=2)
        self.rowconfigure(0, minsize=150, weight=2)
        self.config(bg="grey")

        '''
        #código do easter egg
        tkinter.Button(self, text="Easter Egg", fg='black', bg='yellow', command=self.abrir_janela_EasterEgg).grid(row=0, column=0, pady=20, rowspan=2)
        '''
        
        tkinter.Button(self, text="Calculadora de IMC", fg='white', bg='black', command=self.abrir_janela_imc).grid(row=0, column=0, pady=20)
        tkinter.Button(self, text="Sobre", fg='white', bg='black', command=self.abrir_janela_sobre).grid(row=1, column=0, pady=20)
    
    '''
    #código do easter egg
    def abrir_janela_EasterEgg(self):
        janela_easteregg = JanelaEasterEgg(self)
    '''
    
    def abrir_janela_imc(self):
        janela_imc = JanelaIMC(self)

    def abrir_janela_sobre(self):
        janela_sobre = JanelaSobre(self)

class JanelaIMC(tkinter.Toplevel):
    def __init__(self, chave=None):
        tkinter.Toplevel.__init__(self, chave)
        self.title("Calculadora de IMC")
        self.geometry("250x200")
        
        tkinter.Label(self, text="NOME:").grid(row=0, column=0, padx=10, pady=5)
        self.nome = tkinter.Entry(self)
        self.nome.grid(row=0, column=1, padx=5, pady=5)
        
        tkinter.Label(self, text="PESO(KG):").grid(row=1, column=0, padx=10, pady=5)
        self.peso = tkinter.Entry(self)
        self.peso.grid(row=1, column=1, padx=5, pady=5)
        
        tkinter.Label(self, text="ALTURA(M):").grid(row=2, column=0, padx=10, pady=5)
        self.altura = tkinter.Entry(self)
        self.altura.grid(row=2, column=1, padx=5, pady=5)
        
        #colunspan pra ocupar mais de uma coluna, centralizar
        tkinter.Button(self, text="CALCULAR", command=self.calcular_imc).grid(row=3, column=0, padx=5, pady=20, columnspan=2)
        self.resultado = tkinter.Label(self, text=None)
        self.resultado.grid(row=4, column=0, padx=5, pady=5, columnspan=2)

    def calcular_imc(self):
        nome = self.nome.get()
        peso = float(self.peso.get())
        altura = float(self.altura.get())
        imc = peso/(altura ** 2)
        classificacao = None

        if imc < 18.5:
            classificacao = ("Abaixo do peso")

        elif imc >= 18.5 and imc < 25:
            classificacao = ("com Peso normal")

        elif imc >= 25 and imc < 30:
            classificacao = ("Sobrepeso")

        elif imc >= 30 and imc < 35:
            classificacao = ("com Obesidade grau 1")

        elif imc >= 35 and imc < 40:
            classificacao = ("com Obesidade grau 2")

        else:
            classificacao = ("com Obesidade grau 3")

        resultado = (f"IMC: {imc:.2f} \n Voce está {classificacao}!")
        self.resultado.configure(text=resultado)
        data = datetime.datetime.now().strftime("%d/%m/%Y")
        #Estudar mais wi
        with open("Histórico de IMC.txt", "a") as arquivo:
            arquivo.write(f"------IMC------\n{nome} \n{data} \n{peso}kg \n{altura}m  \nIMC: {imc:.2f} - {classificacao}\n")
        
        self.nome.delete(0, 'end')
        self.peso.delete(0, 'end')
        self.altura.delete(0, 'end')
        
class JanelaSobre(tkinter.Toplevel):
    def __init__(self, chave=None):
        tkinter.Toplevel.__init__(self, chave)
        self.title("Sobre")
        self.geometry("320x150")
        
        tkinter.Label(self, text="EQUIPE:").grid(row=0, column=0, padx=5, pady=5)
        tkinter.Label(self, text="Kayque Rangel Neves Bernardino Peixoto \nAna Beatriz Fernandes Batista \nEllén Vitória Alves Ramalho \nJayne Dias Figueiredo").grid(row=0, column=1, padx=5, pady=5)
        
        tkinter.Label(self, text="DISCIPLINA:").grid(row=1, column=0, padx=5, pady=5)
        tkinter.Label(self, text="Programação Orientada a Objetos").grid(row=1, column=1, padx=5, pady=5)
        
        tkinter.Label(self, text="PROFESSOR:").grid(row=2, column=0, padx=5, pady=5)
        tkinter.Label(self, text="Michel da Silva").grid(row=2, column=1, padx=5, pady=5)

'''
#Easter Egg
class JanelaEasterEgg(tkinter.Toplevel):
     def __init__(self, chave=None):
        tkinter.Toplevel.__init__(self, chave)
        self.title("Easter Egg")
        self.geometry("300x200")
        self.columnconfigure(0, minsize=100, weight=2)
        self.rowconfigure(0, minsize=150, weight=2)

        tkinter.Label(self, text="🥳Parabéns! Você achou o easter egg!🥳").grid(row=0, column=0, rowspan=2, columnspan=2)
        tkinter.Label(self, text=" ♩┏( ･o･) ┛♫").grid(row=1, column=0, pady=10, rowspan=2, columnspan=2)
'''
janela_principal = JanelaPrincipal()
janela_principal.mainloop()
